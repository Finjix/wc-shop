const { errorFrom } = require('./errors');
const { array, string } = require('./validation');

async function getTempFileURLs(runtime, fileList) {
  array(fileList, 'fileList');
  if (!fileList.length || fileList.length > 50) throw errorFrom('INVALID_ARGUMENT', { field: 'fileList' });
  const method = runtime.app && (runtime.app.getTempFileURL || runtime.app.getTempFileUrl);
  if (typeof method !== 'function') throw errorFrom('STORAGE_ERROR');
  const normalized = fileList.map((file) => string(file, 'fileId', { max: 512 }));
  try {
    const result = await method.call(runtime.app, { fileList: normalized });
    return result && result.fileList ? result.fileList : result;
  } catch (error) {
    throw errorFrom('STORAGE_ERROR');
  }
}

module.exports = { getTempFileURLs };
