function createRuntime(options) {
  if (options && options.db) return options;
  // CloudBase cloud functions provide the runtime credentials; no SecretId or SecretKey is read here.
  // eslint-disable-next-line global-require
  const cloudbase = (options && options.cloudbase) || require('@cloudbase/node-sdk');
  const app = (options && options.app) || cloudbase.init({});
  return {
    cloudbase,
    app,
    auth: app.auth(),
    db: app.database(),
  };
}

function getPayload(event) {
  const source = event && typeof event === 'object' ? event : {};
  const nested = source.data && typeof source.data === 'object' && !Array.isArray(source.data)
    ? source.data
    : source;
  const action = source.action || nested.action;
  const data = nested.data && typeof nested.data === 'object' && !Array.isArray(nested.data)
    ? nested.data
    : nested.payload && typeof nested.payload === 'object' && !Array.isArray(nested.payload)
      ? nested.payload
      : nested;
  return { action, data };
}

module.exports = { createRuntime, getPayload };
