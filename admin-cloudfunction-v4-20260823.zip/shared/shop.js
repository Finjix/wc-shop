const crypto = require('crypto');
const {
  COLLECTIONS, STATUS,
} = require('./constants');
const { errorFrom } = require('./errors');
const { getDoc, list, listData, affected, withTransaction } = require('./db');
const { requireUser } = require('./auth');
const { getTempFileURLs } = require('./storage');
const {
  assert, string, optionalString, integer, object, array, page, clone,
} = require('./validation');

function now() { return new Date().toISOString(); }

function valueNumber(value, fallback) {
  const result = Number(value);
  return Number.isFinite(result) ? result : fallback;
}

function collection(runtime, name) { return runtime.db.collection(name); }

async function findDoc(runtime, name, id, field) {
  const direct = await getDoc(collection(runtime, name), id, false);
  if (direct) return direct;
  if (!field) return null;
  const result = await collection(runtime, name).where({ [field]: id }).limit(1).get();
  return listData(result)[0] || null;
}

function skuPrice(sku) {
  if (sku.salePrice !== undefined) return valueNumber(sku.salePrice, 0);
  if (sku.price !== undefined) return valueNumber(sku.price, 0);
  if (Array.isArray(sku.priceInfo)) {
    const sale = sku.priceInfo.find((item) => item.priceType === 1) || sku.priceInfo[0];
    return valueNumber(sale && sale.price, 0);
  }
  return 0;
}

function skuStock(sku) {
  if (sku.stockQuantity !== undefined) return valueNumber(sku.stockQuantity, -1);
  if (sku.stock !== undefined) return valueNumber(sku.stock, -1);
  if (sku.stockInfo && sku.stockInfo.stockQuantity !== undefined) return valueNumber(sku.stockInfo.stockQuantity, -1);
  return -1;
}

function productIdForSku(sku) { return sku.productId || sku.spuId || sku.productRef; }

async function getActiveSku(runtime, skuId, required) {
  const sku = await findDoc(runtime, COLLECTIONS.skus, skuId, 'skuId');
  if (!sku) {
    if (required) throw errorFrom('SKU_UNAVAILABLE');
    return null;
  }
  if (sku.status !== STATUS.active) throw errorFrom('SKU_UNAVAILABLE');
  if (!sku._id && !sku.skuId) throw errorFrom('SKU_UNAVAILABLE');
  return sku;
}

async function getActiveProduct(runtime, id, required) {
  const product = await findDoc(runtime, COLLECTIONS.products, id, 'spuId');
  if (!product) {
    if (required) throw errorFrom('NOT_FOUND');
    return null;
  }
  if (product.status !== STATUS.active) {
    if (required) throw errorFrom('NOT_FOUND');
    return null;
  }
  return product;
}

function publicProduct(product) {
  if (!product) return product;
  const result = { ...product };
  delete result.costPrice;
  delete result.profitPrice;
  delete result.internalNote;
  return result;
}

function publicSku(sku) {
  if (!sku) return sku;
  const result = { ...sku };
  delete result.costPrice;
  delete result.internalNote;
  return result;
}

async function readCategories(runtime, data) {
  const result = await list(collection(runtime, COLLECTIONS.categories), {
    where: { status: STATUS.active },
    orderBy: { field: 'sort', direction: 'asc' },
  });
  return { items: result.items, total: result.items.length };
}

async function readProducts(runtime, data) {
  const paging = page(data);
  const where = { status: STATUS.active };
  if (data.categoryId) where.categoryIds = string(data.categoryId, 'categoryId', { max: 128 });
  const result = await list(collection(runtime, COLLECTIONS.products), {
    where,
    orderBy: { field: data.orderBy === 'price' ? 'minSalePrice' : 'sort', direction: data.direction === 'asc' ? 'asc' : 'desc' },
    skip: (paging.page - 1) * paging.pageSize,
    limit: paging.pageSize,
  });
  let items = result.items;
  if (data.keyword) {
    const keyword = string(data.keyword, 'keyword', { max: 80 }).toLowerCase();
    items = items.filter((item) => `${item.title || ''} ${item.etitle || ''}`.toLowerCase().includes(keyword));
  }
  return { items: items.map(publicProduct), page: paging.page, pageSize: paging.pageSize, total: result.total === undefined ? items.length : result.total };
}

async function readProductDetail(runtime, data) {
  const id = string(data.productId || data.spuId, 'productId', { max: 128 });
  const product = await getActiveProduct(runtime, id, true);
  const skuResult = await list(collection(runtime, COLLECTIONS.skus), { where: { status: STATUS.active, productId: product._id || product.spuId } });
  return { product: publicProduct(product), skus: skuResult.items.map(publicSku) };
}

async function readSkus(runtime, data) {
  const where = { status: STATUS.active };
  if (data.productId || data.spuId) where.productId = string(data.productId || data.spuId, 'productId', { max: 128 });
  const result = await list(collection(runtime, COLLECTIONS.skus), { where });
  return { items: result.items.map(publicSku), total: result.items.length };
}

async function readHome(runtime, data) {
  const where = { status: STATUS.active };
  if (data.slot) where.slot = string(data.slot, 'slot', { max: 64 });
  const result = await list(collection(runtime, COLLECTIONS.homeContents), { where, orderBy: { field: 'sort', direction: 'asc' } });
  return { items: result.items, total: result.items.length };
}

async function getOrCreateUser(runtime, identity, data) {
  const users = collection(runtime, COLLECTIONS.users);
  const existing = await getDoc(users, identity.uid, false);
  const timestamp = now();
  const patch = {
    uid: identity.uid,
    ...(data && data.nickname !== undefined ? { nickname: optionalString(data.nickname, 'nickname', { max: 40 }) } : {}),
    ...(data && data.avatarUrl !== undefined ? { avatarUrl: optionalString(data.avatarUrl, 'avatarUrl', { max: 1024 }) } : {}),
    updatedAt: timestamp,
  };
  if (existing) {
    await users.doc(existing._id || identity.uid).update(patch);
    return { ...existing, ...patch };
  }
  const user = { _id: identity.uid, ...patch, createdAt: timestamp };
  await users.doc(identity.uid).set(user);
  return user;
}

function addressInput(data) {
  const value = object(data.address || data, 'address');
  return {
    receiver: string(value.receiver || value.name, 'receiver', { max: 60 }),
    phone: string(value.phone, 'phone', { max: 32 }),
    province: optionalString(value.province, 'province', { max: 60 }),
    city: optionalString(value.city, 'city', { max: 60 }),
    district: optionalString(value.district, 'district', { max: 60 }),
    detail: string(value.detail || value.address, 'detail', { max: 240 }),
    postalCode: optionalString(value.postalCode, 'postalCode', { max: 16 }),
  };
}

async function listAddresses(runtime, identity) {
  const result = await list(collection(runtime, COLLECTIONS.addresses), { where: { userId: identity.uid }, orderBy: { field: 'isDefault', direction: 'desc' } });
  return { items: result.items, total: result.items.length };
}

async function addressAction(runtime, event, context, data, action) {
  const identity = requireUser(event, context);
  const addresses = collection(runtime, COLLECTIONS.addresses);
  if (action === 'addresses.list') return listAddresses(runtime, identity);
  if (action === 'addresses.get') {
    const item = await getDoc(addresses, string(data.addressId, 'addressId'), true);
    if (item.userId !== identity.uid) throw errorFrom('FORBIDDEN');
    return item;
  }
  if (action === 'addresses.create') {
    const timestamp = now();
    const item = { ...addressInput(data), userId: identity.uid, isDefault: Boolean(data.isDefault), createdAt: timestamp, updatedAt: timestamp };
    if (item.isDefault) await addresses.where({ userId: identity.uid }).update({ isDefault: false });
    const result = await addresses.add(item);
    item._id = result.id || result._id;
    return item;
  }
  const id = string(data.addressId, 'addressId');
  const existing = await getDoc(addresses, id, true);
  if (existing.userId !== identity.uid) throw errorFrom('FORBIDDEN');
  if (action === 'addresses.update') {
    const patch = { ...addressInput(data), updatedAt: now() };
    if (data.isDefault !== undefined) patch.isDefault = Boolean(data.isDefault);
    await addresses.doc(id).update(patch);
    if (patch.isDefault) await addresses.where({ userId: identity.uid }).update({ isDefault: false });
    await addresses.doc(id).update({ ...patch, isDefault: patch.isDefault === true });
    return { ...existing, ...patch, _id: id };
  }
  if (action === 'addresses.setDefault') {
    await addresses.where({ userId: identity.uid }).update({ isDefault: false });
    await addresses.doc(id).update({ isDefault: true, updatedAt: now() });
    return { ...existing, isDefault: true, _id: id };
  }
  if (action === 'addresses.remove') {
    await addresses.doc(id).remove();
    return { addressId: id };
  }
  throw errorFrom('INVALID_ARGUMENT', { field: 'action' });
}

async function getCart(runtime, identity) {
  const cart = await getDoc(collection(runtime, COLLECTIONS.carts), identity.uid, false);
  return { _id: identity.uid, userId: identity.uid, items: (cart && Array.isArray(cart.items) ? cart.items : []), updatedAt: cart && cart.updatedAt };
}

async function cartAction(runtime, event, context, data, action) {
  const identity = requireUser(event, context);
  const carts = collection(runtime, COLLECTIONS.carts);
  const existing = await getCart(runtime, identity);
  const save = async (items) => {
    const saved = { ...existing, items, updatedAt: now() };
    await carts.doc(identity.uid).set(saved);
    return saved;
  };
  if (action === 'cart.get') return existing;
  if (action === 'cart.clear') {
    return save([]);
  }
  if (action === 'cart.clearInvalid') {
    const validItems = [];
    for (const item of existing.items) {
      const sku = await findDoc(runtime, COLLECTIONS.skus, item.skuId, 'skuId');
      const product = sku && await findDoc(runtime, COLLECTIONS.products, productIdForSku(sku), 'spuId');
      const quantity = valueNumber(item.quantity, 0);
      if (sku && sku.status === STATUS.active && product && product.status === STATUS.active && (skuStock(sku) < 0 || skuStock(sku) >= quantity)) validItems.push(item);
    }
    return save(validItems);
  }
  if (action === 'cart.updateAllSelection') return save(existing.items.map((item) => ({ ...item, isSelected: Boolean(data.isSelected) })));
  if (action === 'cart.updateStoreSelection') {
    const storeId = data.storeId === undefined || data.storeId === null ? '' : String(data.storeId);
    return save(existing.items.map((item) => (
      String(item.storeId ?? '') === storeId ? { ...item, isSelected: Boolean(data.isSelected) } : item
    )));
  }

  const skuId = string(data.skuId, 'skuId', { max: 128 });
  const itemIndex = existing.items.findIndex((item) => String(item.skuId) === skuId);
  const items = existing.items.map((item) => ({ ...item }));
  if (action === 'cart.remove') {
    const filtered = items.filter((item) => String(item.skuId) !== skuId);
    return save(filtered);
  }
  if (action === 'cart.updateSelection') {
    if (itemIndex < 0) throw errorFrom('NOT_FOUND');
    items[itemIndex].isSelected = Boolean(data.isSelected);
    return save(items);
  }
  if (action === 'cart.replaceSku') {
    const newSkuId = string(data.newSkuId, 'newSkuId', { max: 128 });
    const quantity = integer(data.quantity, 'quantity', { min: 1, max: 999 });
    const sku = await getActiveSku(runtime, newSkuId, true);
    const product = await getActiveProduct(runtime, productIdForSku(sku), true);
    if (skuStock(sku) >= 0 && quantity > skuStock(sku)) throw errorFrom('OUT_OF_STOCK');
    const filtered = items.filter((item) => String(item.skuId) !== String(data.oldSkuId) && String(item.skuId) !== newSkuId);
    filtered.push({
      skuId: newSkuId,
      spuId: product.spuId || product._id,
      productId: product._id || product.spuId,
      storeId: product.storeId,
      storeName: product.storeName || '',
      quantity,
      isSelected: true,
      title: product.title,
      primaryImage: product.primaryImage || (Array.isArray(product.images) ? product.images[0] : undefined),
      skuSnapshot: clone({ specInfo: sku.specInfo, skuImage: sku.skuImage }),
      unitPrice: skuPrice(sku),
      updatedAt: now(),
    });
    return save(filtered);
  }
  const quantity = integer(data.quantity, 'quantity', { min: 1, max: 999 });
  const sku = await getActiveSku(runtime, skuId, true);
  const product = await getActiveProduct(runtime, productIdForSku(sku), true);
  const nextQuantity = action === 'cart.update' || action === 'cart.updateQuantity'
    ? quantity
    : quantity + (itemIndex >= 0 ? integer(items[itemIndex].quantity, 'quantity', { min: 1 }) : 0);
  if (skuStock(sku) >= 0 && nextQuantity > skuStock(sku)) throw errorFrom('OUT_OF_STOCK');
  const previous = itemIndex >= 0 ? items[itemIndex] : null;
  const cartItem = {
    skuId,
    spuId: product.spuId || product._id,
    productId: product._id || product.spuId,
    storeId: product.storeId,
    storeName: product.storeName || '',
    quantity: nextQuantity,
    isSelected: previous ? Boolean(previous.isSelected) : true,
    title: product.title,
    primaryImage: product.primaryImage || (Array.isArray(product.images) ? product.images[0] : undefined),
    skuSnapshot: clone({ specInfo: sku.specInfo, skuImage: sku.skuImage }),
    unitPrice: skuPrice(sku),
    updatedAt: now(),
  };
  if (itemIndex >= 0) items[itemIndex] = cartItem;
  else items.push(cartItem);
  return save(items);
}

function normalizeOrderItems(value) {
  array(value, 'items');
  assert(value.length > 0 && value.length <= 50, { field: 'items' });
  const merged = new Map();
  value.forEach((item) => {
    const input = object(item, 'items[]');
    const skuId = string(input.skuId, 'skuId', { max: 128 });
    const quantity = integer(input.quantity, 'quantity', { min: 1, max: 999 });
    merged.set(skuId, (merged.get(skuId) || 0) + quantity);
  });
  return Array.from(merged, ([skuId, quantity]) => ({ skuId, quantity }));
}

function orderInput(data = {}) {
  const parameter = data.parameter;
  if (typeof parameter === 'string') return { ...data, orderNo: parameter };
  if (parameter && typeof parameter === 'object' && !Array.isArray(parameter)) return { ...data, ...parameter };
  return data;
}

async function orderDraft(runtime, identity, data, source) {
  const input = orderInput(data);
  const items = normalizeOrderItems(source || input.items || input.goodsRequestList);
  const addressInfo = input.userAddressReq || input.address || {};
  const addressId = string(input.addressId || addressInfo.addressId || addressInfo.id || addressInfo._id, 'addressId', { max: 128 });
  const address = await getDoc(collection(runtime, COLLECTIONS.addresses), addressId, true);
  if (address.userId !== identity.uid) throw errorFrom('FORBIDDEN');
  const resolved = [];
  for (const input of items) {
    const sku = await getActiveSku(runtime, input.skuId, true);
    const product = await getActiveProduct(runtime, productIdForSku(sku), true);
    const stock = skuStock(sku);
    if (stock < input.quantity) throw errorFrom('OUT_OF_STOCK', { skuId: input.skuId });
    const unitPrice = skuPrice(sku);
    if (unitPrice <= 0) throw errorFrom('INVALID_ARGUMENT', { field: 'sku.price' });
    resolved.push({
      skuId: input.skuId,
      productId: product._id || product.spuId,
      quantity: input.quantity,
      unitPrice,
      amount: unitPrice * input.quantity,
      productSnapshot: clone({ _id: product._id, spuId: product.spuId, title: product.title, primaryImage: product.primaryImage, images: product.images }),
      skuSnapshot: clone({ _id: sku._id, skuId: sku.skuId, specInfo: sku.specInfo, skuImage: sku.skuImage }),
    });
  }
  const subtotal = resolved.reduce((sum, item) => sum + item.amount, 0);
  return { items: resolved, addressSnapshot: clone(address), subtotal, totalAmount: subtotal, shippingFee: 0 };
}

async function previewOrder(runtime, event, context, data) {
  const identity = requireUser(event, context);
  const input = orderInput(data);
  const cart = input.useCart ? await getCart(runtime, identity) : null;
  const items = cart ? cart.items : (input.items || input.goodsRequestList);
  const source = cart ? cart.items.map((item) => ({ skuId: item.skuId, quantity: item.quantity })) : items;
  return orderDraft(runtime, identity, input, source);
}

function orderIdFor(userId, requestKey) {
  if (!requestKey) return `ord_${crypto.randomUUID()}`;
  const hash = crypto.createHash('sha256').update(`${userId}:${requestKey}`).digest('hex').slice(0, 32);
  return `ord_${hash}`;
}

async function createOrder(runtime, event, context, data) {
  const identity = requireUser(event, context);
  const input = orderInput(data);
  const requestKey = optionalString(input.requestKey || input.idempotencyKey, 'requestKey', { max: 128 });
  const orderId = orderIdFor(identity.uid, requestKey);
  const requestHash = crypto.createHash('sha256').update(JSON.stringify({ items: input.items || input.goodsRequestList, addressId: input.addressId, useCart: input.useCart })).digest('hex');
  const existing = await getDoc(collection(runtime, COLLECTIONS.orders), orderId, false);
  if (existing) {
    if (existing.requestHash && existing.requestHash !== requestHash) throw errorFrom('IDEMPOTENCY_CONFLICT');
    return existing;
  }
  const result = await withTransaction(runtime.db, async (tx) => {
    const orders = tx.collection(COLLECTIONS.orders);
    const race = await getDoc(orders, orderId, false);
    if (race) {
      if (race.requestHash && race.requestHash !== requestHash) throw errorFrom('IDEMPOTENCY_CONFLICT');
      return race;
    }
    const transactionRuntime = { ...runtime, db: { ...runtime.db, collection: (name) => tx.collection(name), command: runtime.db.command } };
    const cart = input.useCart ? await getCart(transactionRuntime, identity) : null;
    const source = cart ? cart.items.map((item) => ({ skuId: item.skuId, quantity: item.quantity })) : input.items;
    const draft = await orderDraft(transactionRuntime, identity, input, source || input.goodsRequestList);
    const command = runtime.db.command;
    for (const item of draft.items) {
      const sku = await findDoc(transactionRuntime, COLLECTIONS.skus, item.skuId, 'skuId');
      if (!sku || sku.status !== STATUS.active) throw errorFrom('SKU_UNAVAILABLE');
      const stock = skuStock(sku);
      if (stock < item.quantity) throw errorFrom('OUT_OF_STOCK', { skuId: item.skuId });
      const query = tx.collection(COLLECTIONS.skus).where({
        _id: sku._id,
        status: STATUS.active,
        stockQuantity: command && command.gte ? command.gte(item.quantity) : stock,
      });
      const payload = {
        stockQuantity: stock - item.quantity,
        soldQuantity: command && command.inc ? command.inc(item.quantity) : valueNumber(sku.soldQuantity, 0) + item.quantity,
        updatedAt: now(),
      };
      const updateResult = await query.update(payload);
      if (affected(updateResult) !== 1) throw errorFrom('OUT_OF_STOCK', { skuId: item.skuId });
    }
    const timestamp = now();
    const order = {
      _id: orderId,
      orderNo: orderId,
      userId: identity.uid,
      requestKey: requestKey || null,
      requestHash,
      status: STATUS.pendingPayment,
      paymentStatus: 'unpaid',
      payment: null,
      items: draft.items,
      addressSnapshot: draft.addressSnapshot,
      subtotal: draft.subtotal,
      shippingFee: draft.shippingFee,
      totalAmount: draft.totalAmount,
      remark: optionalString(input.remark, 'remark', { max: 240 }) || '',
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    await orders.doc(orderId).set(order);
    if (cart) await tx.collection(COLLECTIONS.carts).doc(identity.uid).set({ _id: identity.uid, userId: identity.uid, items: [], updatedAt: timestamp });
    return order;
  });
  return { ...result, payment: null, paymentRequired: false };
}

async function listOrders(runtime, event, context, data) {
  const identity = requireUser(event, context);
  const input = orderInput(data);
  const paging = page(input);
  const result = await list(collection(runtime, COLLECTIONS.orders), { where: { userId: identity.uid }, orderBy: { field: 'createdAt', direction: 'desc' } });
  const requested = input.orderStatus ?? input.status;
  const statusGroups = {
    5: [STATUS.pendingPayment],
    10: [STATUS.paid],
    40: [STATUS.shipped, STATUS.received],
    50: [STATUS.completed],
    80: [STATUS.cancelled],
  };
  let items = result.items.filter((item) => !item.deletedByUser);
  if (requested !== undefined && requested !== null && requested !== '' && statusGroups[requested]) items = items.filter((item) => statusGroups[requested].includes(item.status));
  else if (requested) items = items.filter((item) => item.status === String(requested));
  const start = (paging.page - 1) * paging.pageSize;
  return { items: items.slice(start, start + paging.pageSize), page: paging.page, pageSize: paging.pageSize, total: items.length };
}

async function orderCount(runtime, event, context) {
  const identity = requireUser(event, context);
  const result = await list(collection(runtime, COLLECTIONS.orders), { where: { userId: identity.uid } });
  const visible = result.items.filter((item) => !item.deletedByUser);
  const count = (statuses) => visible.filter((item) => statuses.includes(item.status)).length;
  return {
    items: [
      { tabType: 5, orderNum: count([STATUS.pendingPayment]) },
      { tabType: 10, orderNum: count([STATUS.paid]) },
      { tabType: 40, orderNum: count([STATUS.shipped, STATUS.received]) },
      { tabType: 50, orderNum: count([STATUS.completed]) },
    ],
  };
}

async function orderDetail(runtime, event, context, data) {
  const identity = requireUser(event, context);
  const input = orderInput(data);
  const order = await getDoc(collection(runtime, COLLECTIONS.orders), string(input.orderId || input.orderNo, 'orderId', { max: 128 }), true);
  if (order.userId !== identity.uid) throw errorFrom('FORBIDDEN');
  return order;
}

async function updateOrderState(runtime, event, context, data, action) {
  const identity = requireUser(event, context);
  const input = orderInput(data);
  const id = string(input.orderId || input.orderNo, 'orderId', { max: 128 });
  const orders = collection(runtime, COLLECTIONS.orders);
  const order = await getDoc(orders, id, true);
  if (order.userId !== identity.uid) throw errorFrom('FORBIDDEN');
  const timestamp = now();
  if (action === 'orders.confirmReceived') {
    if (order.status !== STATUS.shipped) throw errorFrom('ORDER_STATE_INVALID');
    await orders.doc(id).update({ status: STATUS.received, updatedAt: timestamp });
    return { ...order, status: STATUS.received, updatedAt: timestamp };
  }
  if (action === 'orders.delete') {
    if (![STATUS.cancelled, STATUS.completed].includes(order.status)) throw errorFrom('ORDER_STATE_INVALID');
    const patch = { deletedByUser: true, updatedAt: timestamp };
    await orders.doc(id).update(patch);
    return { ...order, ...patch };
  }
  if (action !== 'orders.cancel' || order.status !== STATUS.pendingPayment) throw errorFrom('ORDER_STATE_INVALID');
  return withTransaction(runtime.db, async (tx) => {
    const txOrder = await getDoc(tx.collection(COLLECTIONS.orders), id, true);
    if (txOrder.userId !== identity.uid || txOrder.status !== STATUS.pendingPayment) throw errorFrom('ORDER_STATE_INVALID');
    const command = runtime.db.command;
    for (const item of txOrder.items || []) {
      const sku = await findDoc({ ...runtime, db: { ...runtime.db, collection: (name) => tx.collection(name), command } }, COLLECTIONS.skus, item.skuId, 'skuId');
      if (sku) await tx.collection(COLLECTIONS.skus).doc(sku._id).update({ stockQuantity: command && command.inc ? command.inc(item.quantity) : skuStock(sku) + item.quantity, updatedAt: timestamp });
    }
    await tx.collection(COLLECTIONS.orders).doc(id).update({ status: STATUS.cancelled, updatedAt: timestamp });
    return { ...txOrder, status: STATUS.cancelled, updatedAt: timestamp };
  });
}

async function commentsAction(runtime, event, context, data, action) {
  const identity = requireUser(event, context);
  const query = data.queryParameter && typeof data.queryParameter === 'object' ? { ...data, ...data.queryParameter } : data;
  if (action === 'comments.list') {
    const where = { status: STATUS.active };
    if (query.productId || query.spuId) where.productId = string(query.productId || query.spuId, 'productId', { max: 128 });
    if (query.orderNo || query.orderId) where.orderId = string(query.orderNo || query.orderId, 'orderId', { max: 128 });
    if (query.mineOnly) where.userId = identity.uid;
    const result = await list(collection(runtime, COLLECTIONS.comments), { where, orderBy: { field: 'createdAt', direction: 'desc' } });
    let items = result.items;
    if (query.commentLevel !== undefined && query.commentLevel !== '') {
      const level = Number(query.commentLevel);
      items = items.filter((item) => (level === 1 ? item.rating >= 4 : level === 2 ? item.rating === 3 : item.rating <= 2));
    }
    if (query.hasImage) items = items.filter((item) => Array.isArray(item.images) && item.images.length > 0);
    const paging = { page: query.pageNum === undefined ? 1 : integer(query.pageNum, 'pageNum', { min: 1 }), pageSize: query.pageSize === undefined ? 20 : integer(query.pageSize, 'pageSize', { min: 1, max: 100 }) };
    const start = (paging.page - 1) * paging.pageSize;
    return { items: items.slice(start, start + paging.pageSize), page: paging.page, pageSize: paging.pageSize, total: items.length };
  }
  if (action === 'comments.count') {
    const where = { status: STATUS.active };
    if (data.productId || data.spuId) where.productId = string(data.productId || data.spuId, 'productId', { max: 128 });
    const result = await list(collection(runtime, COLLECTIONS.comments), { where });
    const items = result.items;
    return {
      commentCount: items.length,
      goodCount: items.filter((item) => Number(item.rating) >= 4).length,
      middleCount: items.filter((item) => Number(item.rating) === 3).length,
      badCount: items.filter((item) => Number(item.rating) <= 2).length,
      hasImageCount: items.filter((item) => Array.isArray(item.images) && item.images.length > 0).length,
      uidCount: new Set(items.map((item) => item.userId)).size,
    };
  }
  if (action !== 'comments.create') throw errorFrom('INVALID_ARGUMENT', { field: 'action' });
  const orderId = string(data.orderId || data.orderNo, 'orderId', { max: 128 });
  const order = await getDoc(collection(runtime, COLLECTIONS.orders), orderId, true);
  if (order.userId !== identity.uid || ![STATUS.received, STATUS.completed].includes(order.status)) throw errorFrom('FORBIDDEN');
  const candidateProductId = data.productId || data.spuId;
  const matchedItem = (order.items || []).find((item) => item.productId === candidateProductId || item.spuId === candidateProductId || item.productSnapshot?.spuId === candidateProductId || item.productSnapshot?._id === candidateProductId);
  const fallbackProductId = order.items && order.items[0] && order.items[0].productId;
  const productId = string(matchedItem?.productId || candidateProductId || fallbackProductId, 'productId', { max: 128 });
  assert((order.items || []).some((item) => item.productId === productId), { field: 'productId' });
  const text = optionalString(data.content ?? data.commentContent, 'content', { max: 2000 }) || '';
  const sourceImages = data.images ?? data.commentResources;
  const images = sourceImages === undefined ? [] : array(sourceImages, 'images').slice(0, 9).map((item) => string(typeof item === 'string' ? item : item && (item.image || item.fileID || item.fileId), 'images[]', { max: 1024 }));
  const timestamp = now();
  const rating = data.rating ?? data.commentScore;
  const comment = { userId: identity.uid, orderId, productId, rating: rating === undefined ? 5 : integer(Number(rating), 'rating', { min: 1, max: 5 }), content: text, images, status: STATUS.pendingReview, createdAt: timestamp, updatedAt: timestamp };
  const result = await collection(runtime, COLLECTIONS.comments).add(comment);
  comment._id = result.id || result._id;
  return comment;
}

async function afterSalesAction(runtime, event, context, data, action) {
  const identity = requireUser(event, context);
  const afterSales = collection(runtime, COLLECTIONS.afterSales);
  if (action === 'afterSales.list') {
    const paging = page(data);
    const result = await list(afterSales, { where: { userId: identity.uid }, orderBy: { field: 'createdAt', direction: 'desc' } });
    const items = data.status ? result.items.filter((item) => item.status === String(data.status)) : result.items;
    const start = (paging.page - 1) * paging.pageSize;
    return { items: items.slice(start, start + paging.pageSize), page: paging.page, pageSize: paging.pageSize, total: items.length };
  }
  if (action === 'afterSales.reasons') return { items: ['质量问题', '商品错发', '商品少发', '不想要了', '其他'] };
  if (action === 'afterSales.detail') {
    const ref = string(data.afterSaleId || data.rightsNo, 'afterSaleId', { max: 128 });
    const item = await findDoc(runtime, COLLECTIONS.afterSales, ref, 'rightsNo');
    if (!item) throw errorFrom('NOT_FOUND');
    if (item.userId !== identity.uid) throw errorFrom('FORBIDDEN');
    return item;
  }
  if (action === 'afterSales.confirmReceived') {
    const orderId = string(data.orderId || data.orderNo, 'orderId', { max: 128 });
    const orders = collection(runtime, COLLECTIONS.orders);
    const order = await getDoc(orders, orderId, true);
    if (order.userId !== identity.uid) throw errorFrom('FORBIDDEN');
    if (order.status !== STATUS.shipped) throw errorFrom('ORDER_STATE_INVALID');
    const patch = { status: STATUS.received, updatedAt: now() };
    await orders.doc(orderId).update(patch);
    return { ...order, ...patch };
  }
  if (action === 'afterSales.submitTracking') {
    const ref = string(data.afterSaleId || data.rightsNo, 'afterSaleId', { max: 128 });
    const item = await findDoc(runtime, COLLECTIONS.afterSales, ref, 'rightsNo');
    if (!item) throw errorFrom('NOT_FOUND');
    if (item.userId !== identity.uid) throw errorFrom('FORBIDDEN');
    const trackingNo = string(data.trackingNo || data.logisticsNo, 'trackingNo', { max: 128 });
    const patch = {
      logisticsNo: trackingNo,
      logisticsCompanyName: optionalString(data.logisticsCompanyName || data.companyName, 'logisticsCompanyName', { max: 120 }) || '',
      logisticsCompanyCode: optionalString(data.logisticsCompanyCode || data.companyCode, 'logisticsCompanyCode', { max: 80 }) || '',
      status: item.status === STATUS.approved ? STATUS.refunding : item.status,
      updatedAt: now(),
    };
    await afterSales.doc(item._id).update(patch);
    return { ...item, ...patch, _id: item._id };
  }
  const orderId = string(data.orderId || data.orderNo, 'orderId', { max: 128 });
  const order = await getDoc(collection(runtime, COLLECTIONS.orders), orderId, true);
  if (order.userId !== identity.uid) throw errorFrom('FORBIDDEN');
  if (action === 'afterSales.preview') {
    const response = { orderId, items: order.items || [], allowed: [STATUS.shipped, STATUS.received, STATUS.completed].includes(order.status) };
    if (data.includeReasons) response.rightsReasonList = ['质量问题', '商品错发', '商品少发', '不想要了', '其他'].map((item) => ({ id: item, desc: item }));
    return response;
  }
  if (action !== 'afterSales.create') throw errorFrom('INVALID_ARGUMENT', { field: 'action' });
  if (![STATUS.shipped, STATUS.received, STATUS.completed].includes(order.status)) throw errorFrom('ORDER_STATE_INVALID');
  const timestamp = now();
  const requestedProductId = data.productId || data.spuId;
  const snapshot = (order.items || []).find((orderItem) => !requestedProductId || orderItem.productId === requestedProductId || orderItem.spuId === requestedProductId || orderItem.productSnapshot?.spuId === requestedProductId || orderItem.productSnapshot?._id === requestedProductId);
  const item = { userId: identity.uid, rightsNo: `as_${crypto.randomUUID()}`, orderId, productId: optionalString(snapshot?.productId || requestedProductId, 'productId', { max: 128 }), type: String(data.type || data.rightsType || 'refund'), reason: string(data.reason || data.rightsReasonDesc, 'reason', { max: 120 }), description: optionalString(data.description || data.refundMemo, 'description', { max: 1000 }) || '', images: Array.isArray(data.images) ? data.images.slice(0, 9) : [], items: snapshot ? [clone(snapshot)] : [], status: STATUS.pendingReview, createdAt: timestamp, updatedAt: timestamp };
  const result = await afterSales.add(item);
  item._id = result.id || result._id;
  return item;
}

async function shopEndpoint(event, context, runtime, action, data) {
  if (action === 'categories.list') return readCategories(runtime, data);
  if (action === 'products.list') return readProducts(runtime, data);
  if (action === 'products.detail') return readProductDetail(runtime, data);
  if (action === 'skus.list') return readSkus(runtime, data);
  if (action === 'home.get') return readHome(runtime, data);
  if (action === 'storage.tempUrls') {
    requireUser(event, context);
    return getTempFileURLs(runtime, data.fileList);
  }
  if (action === 'user.me' || action === 'user.update') return getOrCreateUser(runtime, requireUser(event, context), data);
  if (action.startsWith('addresses.')) return addressAction(runtime, event, context, data, action);
  if (action.startsWith('cart.')) return cartAction(runtime, event, context, data, action);
  if (action === 'orders.preview') return previewOrder(runtime, event, context, data);
  if (action === 'orders.create') return createOrder(runtime, event, context, data);
  if (action === 'orders.list') return listOrders(runtime, event, context, data);
  if (action === 'orders.count') return orderCount(runtime, event, context);
  if (action === 'orders.businessTime') return { telphone: '', telephone: '', phone: '' };
  if (action === 'orders.detail') return orderDetail(runtime, event, context, data);
  if (action === 'orders.cancel' || action === 'orders.confirmReceived' || action === 'orders.delete') return updateOrderState(runtime, event, context, data, action);
  if (action.startsWith('comments.')) return commentsAction(runtime, event, context, data, action);
  if (action.startsWith('afterSales.')) return afterSalesAction(runtime, event, context, data, action);
  throw errorFrom('INVALID_ARGUMENT', { field: 'action' });
}

module.exports = { shopEndpoint, normalizeOrderItems, skuPrice, skuStock };
